<template>
    <div class="verify-receivables">
      收款对账
    </div>
</template>

<script>
    export default {
        name: 'verifyReceivables',
        data () {
            return {}
        }
    }
</script>
<style scoped>

</style>
