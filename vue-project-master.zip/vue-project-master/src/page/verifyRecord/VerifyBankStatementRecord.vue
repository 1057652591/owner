<template>
    <div class="hello">
      对账记录银行对账
    </div>
</template>

<script>
    export default {
        name: 'HelloWorld',
        data () {
            return {}
        }
    }
</script>
<style scoped>

</style>
