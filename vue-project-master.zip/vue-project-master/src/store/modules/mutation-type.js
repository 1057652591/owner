/**
 * Created by 不动的推动者 on 2018/5/2.
 */
//
export const COLLAPSE = 'COLLAPSE' //左侧边栏隐藏状态
export const COMPANY = 'COMPANY' //公司
export const VERIFY_STATUS = 'VERIFY_STATUS' //
export const ORDER_LIST_INFO = 'ORDER_LIST_INFO' //
export const DIALOG_FROM_AUDIT = 'DIALOG_FROM_AUDIT' //批量审核框
export const DIALOG_FROM_UN_AUDIT = 'DIALOG_FROM_UN_AUDIT' //批量反审核框
export const DIALOG_FROM_DIFFERENCES = 'DIALOG_FROM_DIFFERENCES'   //批量差异对帐
export const DIALOG_FROM_DELETE = 'DIALOG_FROM_DELETE' //批量删除
export const DIALOG_FROM_STATEMENT = 'DIALOG_FROM_STATEMENT' //报表通用弹出层
export const DIALOGGET_WEB_SOCKET = 'DIALOGGET_WEB_SOCKET' //websocket
